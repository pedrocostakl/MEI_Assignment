LeetCode


----Hard-----
Problem 185 - Hard - Accepted, Runtime: 128 ms
Problem 262 - Hard - Accepted, Runtime: 94 ms
Problem 601 - Hard - Accepted, Runtime: 82 ms
Problem 3451 - Hard - Accepted, Runtime: 84 ms
Problem 3374 - Hard - Runtime error syntax error, Runtime: 84 ms
Problem 3482 - Hard - Accepted, Runtime: 94 ms
Problem 3673 - Hard - Accepted, Runtime: 88 ms
Problem 3617 - Hard - Accepted, Runtime: 120 ms
Problem 3832 - Hard - Runtime Error - didnt respect context restrictions
Problem 3764 - Hard - Accepted, Runtime: 106 ms
Problem 1581 - Hard - Accepted, Runtime: 80 ms
Problem 2356 - Hard - Accepted, Runtime: 78 ms
Problem 1978 - Hard - Accepted, Runtime: 68 ms
Problem 1965 - Hard - Accepted, Runtime: 71 ms
Problem 1890 - Hard - Accepted, Runtime: 88 ms
Problem 1873 - Hard - Accepted, Runtime: 82 ms
Problem 1789 - Hard - Accepted, Runtime: 102 ms
Problem 1757 - Hard - Accepted, Runtime: 81 ms
Problem 1741 - Hard - Accepted, Runtime: 96 ms
Problem Interviews Hard - Wrong Answer 
Problem 15 days - Hard - Accepted


----Medium----
Problem 176 - Medium - Accepted, Runtime: 90 ms
Problem 177 - Medium - Accepted, Runtime: 103 ms
Problem 178 - Medium - Runtime Error, Syntax Error
Problem 180 - Medium - Accepted, Runtime: 74 ms
Problem 184 - Medium - Accepted, Runtime: 130 ms
Problem 550 - Medium - Accepted, Runtime: 80 ms
Problem 570 - Medium - Accepted, Runtime: 102 ms
Problem 585 - Medium - Accepted, Runtime: 71 ms
Problem 602 - Medium - Accepted, Runtime: 75 ms
Problem 608 - Medium - Accepted, Runtime: 83 ms
Problem 626 - Medium - Accepted, Runtime: 79 ms
Problem 1045 - Medium - Accepted, Runtime: 118 ms
Problem 1070 - Medium - Accepted, Runtime: 83 ms
Problem 1158 - Medium - Accepted, Runtime: 147 ms
Problem 1164 - Medium - Accepted, Runtime: 62 ms
Problem 1174 - Medium - Accepted, Runtime: 73 ms
Problem 1193 - Medium - Accepted, Runtime: 222 ms
Problem 1204 - Medium - Accepted, Runtime: 65 ms
Problem 1321 - Medium - Accepted, Runtime: 70 ms
Problem 1341 - Medium - Accepted, Runtime: 147 ms
Problem 1393 - Medium - Accepted, Runtime: 76 ms

--------Easy------
Problem 175 - Easy - Accepted, Runtime: 114ms
Problem 181 - Easy - Accepted, Runtime: 80ms
Problem 182 - Easy - Accepted, Runtime: 70ms
Problem 183 - Easy - Accepted, Runtime: 94ms
Problem 196 - Easy - Accepted, Runtime: 70ms
Problem 197 - Easy - Accepted, Runtime: 68ms
Problem 511 - Easy - Accepted, Runtime: 74ms
Problem 577 - Easy - Accepted, Runtime: 644ms
Problem 584 - Easy - Accepted, Runtime: 79ms
Problem 586 - Easy - Accepted, Runtime: 79ms
Problem 595 - Easy - Accepted, Runtime: 78ms
Problem 596 - Easy - Accepted, Runtime: 67ms
Problem 607 - Easy - Accepted, Runtime: 121ms
Problem 610 - Easy - Accepted, Runtime: 80ms
Problem 619 - Easy - Accepted, Runtime: 118ms
Problem 620 - Easy - Accepted, Runtime: 75ms
Problem 627 - Easy - Accepted, Runtime: 90ms
Problem 1050 - Easy - Accepted, Runtime: 93ms
Problem 1068 - Easy - Accepted, Runtime: 112ms
Problem 1075 - Easy - Accepted, Runtime: 136ms
Problem 1084 - Easy - Accepted, Runtime: 445ms
